/**
 * Simulación EXPERIMENTAL de selecciones que el ValueBettingEngine rechazó.
 *
 * Propósito: comprobar si las reglas del motor descartan cosas que habrían
 * funcionado (o confirmar que descartan lo correcto). Estas filas NO son
 * apuestas recomendadas, no entran en el panel de Rendimiento, ni en el
 * límite por jornada, ni en la regla de parada del CLV.
 *
 * Fuente: value_evaluations con recommended = false. Se toma UNA fila por
 * partido y selección: la última captura de cuotas anterior al inicio.
 */
import { MARKETS, profitMultiplier, hitValue, selectionLabel } from '../model/markets.js';
import { meanCI, wilsonCI } from '../lib/stats.js';
import { COMPETITION_NAMES, codeForSlug } from '../competitions.js';

export const EXPERIMENTAL_DISCLAIMER =
  'Simulación experimental: selecciones que el sistema rechazó. No son apuestas recomendadas ni cuentan para el rendimiento real.';

const SETTLED = ['won', 'lost', 'half_won', 'half_lost', 'void'];
const round = (x, d = 2) => (x == null || !Number.isFinite(Number(x)) ? null : Number(Number(x).toFixed(d)));
const num = v => (v == null ? null : Number(v));

/** Agrupa el texto libre del motor en categorías estables para el panel. */
export function reasonCategory(reason) {
  const r = String(reason || '').toLowerCase();
  if (!r) return 'Sin motivo registrado';
  if (r.includes('ev insuficiente')) return 'EV insuficiente';
  if (r.includes('se desvía')) return 'Modelo demasiado lejos del mercado';
  if (r.includes('rango de validación')) return 'Cuota fuera de rango';
  if (r.includes('menos de') && r.includes('casas')) return 'Pocas casas en el mercado';
  if (r.includes('límite') || r.includes('ya hay una señal')) return 'Límite por jornada o partido';
  if (r.includes('sin modelo')) return 'Sin modelo propio';
  if (r.includes('no hay cuota') || r.includes('sin probabilidad de mercado')) return 'Sin datos de mercado';
  if (r.includes('mercado no habilitado')) return 'Mercado no habilitado';
  return 'Otros';
}

function toRow(r) {
  const status = r.status || 'pending';
  const odds = num(r.odds);
  const settled = SETTLED.includes(status);
  const home = r.home, away = r.away;
  return {
    id: r.id,
    fixtureId: r.fixture_id,
    kickoff: r.kickoff_utc,
    home, away,
    competitionSlug: r.competition_slug,
    competition: COMPETITION_NAMES[codeForSlug(r.competition_slug)] || r.competition_slug,
    market: r.market,
    marketLabel: MARKETS[r.market]?.label || r.market,
    selection: r.selection,
    line: num(r.line) ?? 0,
    label: selectionLabel(r.selection, num(r.line), { home, away }),
    odds,
    bookmaker: r.bookmaker || null,
    oddsCapturedAt: r.odds_captured_at,
    probability: num(r.blended_probability) ?? num(r.calibrated_probability) ?? num(r.model_probability),
    marketProbability: num(r.market_probability),
    ev: num(r.ev),
    reason: r.reason || null,
    category: reasonCategory(r.reason),
    status,
    score: r.home_goals != null && r.away_goals != null ? `${r.home_goals}-${r.away_goals}` : null,
    // Resultado con 1 unidad plana, solo si el partido ya terminó.
    profit: settled ? round(profitMultiplier(status, odds), 3) : null,
    clv: num(r.clv),
    recommended: false,
    experimental: true
  };
}

function aggregate(list) {
  const settled = list.filter(x => SETTLED.includes(x.status) && x.status !== 'void');
  const graded = list.filter(x => hitValue(x.status) != null);
  const hits = graded.reduce((a, x) => a + hitValue(x.status), 0);
  return {
    total: list.length,
    settled: settled.length,
    pending: list.filter(x => x.status === 'pending').length,
    hitRate: wilsonCI(hits, graded.length),
    yield: meanCI(settled.map(x => x.profit), { scale: 100 }),
    avgOdds: list.length ? round(list.reduce((a, x) => a + (x.odds || 0), 0) / list.length) : null
  };
}

/**
 * @param {Array} dbRows filas crudas de value_evaluations (recommended = false)
 */
export function buildExperimental(dbRows, { limit = 60 } = {}) {
  const rows = dbRows.map(toRow);

  const byReason = {};
  for (const r of rows) (byReason[r.category] ||= []).push(r);
  const reasons = Object.entries(byReason)
    .map(([category, list]) => ({ category, ...aggregate(list) }))
    .sort((a, b) => b.total - a.total);

  const positive = rows.filter(r => r.ev != null && r.ev > 0);

  return {
    disclaimer: EXPERIMENTAL_DISCLAIMER,
    method:
      'Una fila por partido y selección (última captura de cuotas antes del inicio), 1 unidad plana. ' +
      'Las selecciones del mismo partido están correlacionadas, así que los intervalos son orientativos.',
    all: aggregate(rows),
    positiveEv: aggregate(positive),
    byReason: reasons,
    rows: rows
      .sort((a, b) => String(b.kickoff).localeCompare(String(a.kickoff)) || (b.ev ?? -1) - (a.ev ?? -1))
      .slice(0, limit)
  };
}

/** Consulta SQL (PostgreSQL) para el servicio de señales. */
export const EXPERIMENTAL_SQL = `
  SELECT DISTINCT ON (fixture_id, market, selection, line) *
    FROM value_evaluations
   WHERE competition_slug IN ('la_liga', 'champions_league')
     AND recommended = false
     AND ev IS NOT NULL
     AND odds_captured_at < kickoff_utc
     AND kickoff_utc >= now() - ($1 || ' days')::interval
   ORDER BY fixture_id, market, selection, line, odds_captured_at DESC`;
