/**
 * Combinadas del MISMO partido (same-game parlay).
 *
 * Los mercados de un mismo partido NO son independientes: "gana el local" y
 * "más de 2.5 goles" se favorecen entre sí, "empate" y "más de 2.5" se
 * penalizan. Multiplicar probabilidades sería un error. Aquí la probabilidad
 * conjunta se calcula sumando las celdas de la matriz de marcadores que
 * cumplen TODAS las selecciones a la vez, de modo que las dependencias salen
 * de la propia distribución de goles.
 *
 * Opcionalmente la matriz se reajusta (IPF) para que sus marginales coincidan
 * con las probabilidades calibradas de producción, conservando la estructura
 * de dependencia entre mercados.
 *
 * Mercados admitidos: 1X2, doble oportunidad, más/menos 2.5 y ambos marcan.
 * El hándicap asiático se excluye (tiene "push" y complica la liquidación).
 */

export const SAME_GAME_MARKETS = {
  '1x2': ['home', 'draw', 'away'],
  double_chance: ['dc_1x', 'dc_x2', 'dc_12'],
  over_under: ['over25', 'under25'],
  btts: ['btts_yes', 'btts_no']
};

const MARKET_OF = Object.fromEntries(
  Object.entries(SAME_GAME_MARKETS).flatMap(([m, sels]) => sels.map(s => [s, m]))
);

export const SAME_GAME_SELECTIONS = Object.keys(MARKET_OF);

/** Condición de cada selección sobre el marcador (h = local, a = visitante). */
const PREDICATES = {
  home: (h, a) => h > a,
  draw: (h, a) => h === a,
  away: (h, a) => a > h,
  dc_1x: (h, a) => h >= a,
  dc_x2: (h, a) => a >= h,
  dc_12: (h, a) => h !== a,
  over25: (h, a) => h + a >= 3,
  under25: (h, a) => h + a < 3,
  btts_yes: (h, a) => h >= 1 && a >= 1,
  btts_no: (h, a) => h === 0 || a === 0
};

export function sameGameMarket(selection) {
  return MARKET_OF[selection] || null;
}

/** Probabilidad de que se cumplan todas las selecciones a la vez. */
export function jointProbability(matrix, selections) {
  const preds = selections.map(s => PREDICATES[s]);
  if (!matrix || preds.some(p => !p)) return null;
  let total = 0;
  for (let h = 0; h < matrix.length; h++) {
    for (let a = 0; a < matrix[h].length; a++) {
      if (preds.every(p => p(h, a))) total += matrix[h][a];
    }
  }
  return total;
}

/**
 * Reajusta la matriz (ajuste proporcional iterativo) para que sus marginales
 * 1X2, más/menos 2.5 y ambos marcan coincidan con `targets`. Los grupos sin
 * objetivo no se tocan. Devuelve una matriz nueva normalizada.
 */
export function fitMatrixToMarginals(matrix, targets = {}, { iterations = 60, tolerance = 1e-7 } = {}) {
  const groups = [
    { sels: ['home', 'draw', 'away'] },
    { sels: ['over25', 'under25'] },
    { sels: ['btts_yes', 'btts_no'] }
  ].filter(g => g.sels.every(s => Number.isFinite(targets[s]) && targets[s] > 0));

  const m = matrix.map(row => [...row]);
  if (!groups.length) return m;

  for (let it = 0; it < iterations; it++) {
    let worst = 0;
    for (const g of groups) {
      const sum = Object.fromEntries(g.sels.map(s => [s, 0]));
      for (let h = 0; h < m.length; h++) {
        for (let a = 0; a < m[h].length; a++) {
          for (const s of g.sels) if (PREDICATES[s](h, a)) sum[s] += m[h][a];
        }
      }
      const tSum = g.sels.reduce((acc, s) => acc + targets[s], 0);
      for (const s of g.sels) {
        const want = targets[s] / tSum;
        worst = Math.max(worst, Math.abs(sum[s] - want));
      }
      for (let h = 0; h < m.length; h++) {
        for (let a = 0; a < m[h].length; a++) {
          for (const s of g.sels) {
            if (PREDICATES[s](h, a) && sum[s] > 0) m[h][a] *= (targets[s] / tSum) / sum[s];
          }
        }
      }
    }
    if (worst < tolerance) break;
  }
  const total = m.reduce((acc, row) => acc + row.reduce((x, y) => x + y, 0), 0);
  if (total > 0) for (const row of m) for (let a = 0; a < row.length; a++) row[a] /= total;
  return m;
}

/**
 * Evalúa una combinación de selecciones del mismo partido.
 * @returns {{ ok:boolean, reason?:string, selections, joint, independent, correlation,
 *             marginals, fairOdds, redundant:boolean }}
 */
export function evaluateCombo(matrix, selections) {
  const sels = [...new Set(selections)];
  if (sels.length < 2) return { ok: false, reason: 'Hacen falta al menos 2 selecciones.', selections: sels };
  if (sels.some(s => !MARKET_OF[s])) return { ok: false, reason: 'Selección no admitida en combinadas del mismo partido.', selections: sels };

  const markets = sels.map(s => MARKET_OF[s]);
  if (new Set(markets).size !== markets.length) {
    return { ok: false, reason: 'No se pueden combinar dos selecciones del mismo mercado.', selections: sels };
  }

  const joint = jointProbability(matrix, sels);
  if (!(joint > 1e-9)) {
    return { ok: false, reason: 'Selecciones incompatibles: no pueden cumplirse a la vez.', selections: sels, joint: joint ?? 0 };
  }

  const marginals = Object.fromEntries(sels.map(s => [s, jointProbability(matrix, [s])]));
  const independent = sels.reduce((acc, s) => acc * marginals[s], 1);
  // Redundante: una selección ya implica a las demás (la probabilidad conjunta
  // coincide con la de la más restrictiva). Ejemplo: "gana local" + "1X".
  const minMarginal = Math.min(...Object.values(marginals));
  const redundant = Math.abs(joint - minMarginal) < 1e-9;

  return {
    ok: true,
    selections: sels,
    joint,
    independent,
    correlation: independent > 0 ? joint / independent : null,
    marginals,
    fairOdds: 1 / joint,
    redundant
  };
}

function* combinations(arr, k, start = 0, acc = []) {
  if (acc.length === k) { yield [...acc]; return; }
  for (let i = start; i < arr.length; i++) {
    acc.push(arr[i]);
    yield* combinations(arr, k, i + 1, acc);
    acc.pop();
  }
}

/**
 * Lista todas las combinaciones compatibles de 2..maxLegs selecciones (a lo
 * sumo una por mercado), sin redundantes, ordenadas por probabilidad conjunta.
 */
export function suggestCombos(matrix, { maxLegs = 3, minJoint = 0.08, limit = 20, selections = SAME_GAME_SELECTIONS } = {}) {
  const out = [];
  for (let k = 2; k <= Math.min(maxLegs, 4); k++) {
    for (const combo of combinations(selections, k)) {
      const r = evaluateCombo(matrix, combo);
      if (!r.ok || r.redundant || r.joint < minJoint) continue;
      out.push(r);
    }
  }
  return out.sort((a, b) => b.joint - a.joint).slice(0, limit);
}

/**
 * Valor esperado frente a la cuota que ofrezca la casa por la combinada.
 * La cuota NO se calcula multiplicando las de cada pata: las casas recortan
 * el precio cuando las selecciones están correlacionadas positivamente.
 */
export function comboValue(joint, offeredOdds) {
  const o = Number(offeredOdds);
  if (!(joint > 0) || !(o > 1)) return null;
  return { ev: joint * o - 1, fairOdds: 1 / joint, offeredOdds: o };
}

/** Cuota mínima que haría falta para alcanzar un EV objetivo. */
export function minimumOddsFor(joint, minEv = 0.05) {
  return joint > 0 ? (1 + minEv) / joint : null;
}
