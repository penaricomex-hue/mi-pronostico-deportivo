import test from 'node:test';
import assert from 'node:assert/strict';
import { scoreMatrix, marketsFromMatrix } from '../server/model/poisson.js';
import {
  jointProbability, evaluateCombo, suggestCombos, fitMatrixToMarginals, comboValue, minimumOddsFor, sameGameMarket
} from '../server/model/sameGame.js';

const M = scoreMatrix(1.6, 1.0, -0.06);

test('la probabilidad conjunta suma 1 sobre una partición y coincide con los marginales', () => {
  const total = ['home', 'draw', 'away'].reduce((a, s) => a + jointProbability(M, [s]), 0);
  assert.ok(Math.abs(total - 1) < 1e-9);
  const p = marketsFromMatrix(M);
  assert.ok(Math.abs(jointProbability(M, ['over25']) - p.over25) < 1e-9);
  assert.ok(Math.abs(jointProbability(M, ['btts_yes']) - p.btts) < 1e-9);
});

test('local + más de 2.5 NO es el producto de las probabilidades: hay dependencia', () => {
  const c = evaluateCombo(M, ['home', 'over25']);
  assert.ok(c.ok);
  assert.ok(c.joint > 0 && c.joint < Math.min(c.marginals.home, c.marginals.over25));
  assert.notEqual(Math.round(c.joint * 1e4), Math.round(c.independent * 1e4));
  assert.ok(c.correlation > 1, 'ganar el local y muchos goles se favorecen');
});

test('empate + más de 2.5 se penalizan; empate + menos de 2.5 se favorecen', () => {
  assert.ok(evaluateCombo(M, ['draw', 'over25']).correlation < 1);
  assert.ok(evaluateCombo(M, ['draw', 'under25']).correlation > 1);
});

test('las incompatibles se rechazan, no se multiplican', () => {
  const same = evaluateCombo(M, ['home', 'draw']);
  assert.equal(same.ok, false);
  assert.match(same.reason, /mismo mercado/);
  // Mismo partido imposible: gana local y "menos de 2.5" con ambos marcan no lo es, pero
  // empate + gana local sí lo es; comprobamos una incompatibilidad lógica real:
  const impossible = evaluateCombo(M, ['away', 'dc_1x']);
  assert.equal(impossible.ok, false);
  assert.match(impossible.reason, /incompatibles/);
  assert.equal(evaluateCombo(M, ['home']).ok, false);
  assert.equal(evaluateCombo(M, ['home', 'ah_home']).ok, false, 'el hándicap asiático no se combina');
});

test('se detecta la redundancia (gana local ya implica 1X)', () => {
  const c = evaluateCombo(M, ['home', 'dc_1x']);
  assert.ok(c.ok && c.redundant);
});

test('las sugerencias son compatibles, sin redundantes, ordenadas y con una selección por mercado', () => {
  const list = suggestCombos(M, { maxLegs: 3, minJoint: 0.05, limit: 50 });
  assert.ok(list.length > 5);
  for (let i = 1; i < list.length; i++) assert.ok(list[i - 1].joint >= list[i].joint);
  for (const c of list) {
    assert.ok(!c.redundant);
    const markets = c.selections.map(s => sameGameMarket(s));
    assert.equal(new Set(markets).size, markets.length);
  }
});

test('ajuste a marginales calibrados: respeta los objetivos y mantiene la dependencia', () => {
  const targets = { home: 0.40, draw: 0.28, away: 0.32, over25: 0.45, under25: 0.55, btts_yes: 0.50, btts_no: 0.50 };
  const fit = fitMatrixToMarginals(M, targets);
  const total = fit.flat().reduce((a, b) => a + b, 0);
  assert.ok(Math.abs(total - 1) < 1e-9);
  for (const [s, p] of Object.entries(targets)) assert.ok(Math.abs(jointProbability(fit, [s]) - p) < 1e-4, s);
  const c = evaluateCombo(fit, ['home', 'over25']);
  assert.ok(c.correlation > 1, 'sigue habiendo correlación positiva tras el ajuste');
  // Sin objetivos la matriz no cambia
  assert.deepEqual(fitMatrixToMarginals(M, {}), M);
});

test('EV y cuota mínima de la combinada', () => {
  const c = evaluateCombo(M, ['home', 'over25']);
  const v = comboValue(c.joint, 4);
  assert.ok(Math.abs(v.ev - (c.joint * 4 - 1)) < 1e-12);
  assert.ok(Math.abs(minimumOddsFor(c.joint, 0.05) * c.joint - 1.05) < 1e-12);
  assert.equal(comboValue(c.joint, 1), null);
});

test('simulación Monte Carlo coincide con la probabilidad conjunta (±1 pt)', () => {
  let s = 12345;
  const rand = () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 2 ** 32; };
  const cells = [];
  let acc = 0;
  for (let h = 0; h < M.length; h++) for (let a = 0; a < M[h].length; a++) { acc += M[h][a]; cells.push([acc, h, a]); }
  let hit = 0;
  const N = 200000;
  for (let i = 0; i < N; i++) {
    const u = rand();
    const [, h, a] = cells.find(c => u <= c[0]) || cells[cells.length - 1];
    if (h > a && h + a >= 3 && h >= 1 && a >= 1) hit++;
  }
  const expected = jointProbability(M, ['home', 'over25', 'btts_yes']);
  assert.ok(Math.abs(hit / N - expected) < 0.01);
});
