import test from 'node:test';
import assert from 'node:assert/strict';
import { buildExperimental, reasonCategory, EXPERIMENTAL_DISCLAIMER } from '../server/services/experimental.js';

const row = (o = {}) => ({
  id: 1, fixture_id: 'f1', kickoff_utc: '2026-10-10T19:00:00Z', competition_slug: 'la_liga',
  home: 'Real Madrid', away: 'Sevilla', market: '1x2', selection: 'home', line: 0, odds: 2.1, bookmaker: 'Pinnacle',
  odds_captured_at: '2026-10-10T10:00:00Z', calibrated_probability: 0.5, market_probability: 0.46, ev: 0.03,
  reason: 'EV insuficiente', status: 'won', home_goals: 2, away_goals: 0, clv: null, ...o
});

test('las categorías de rechazo agrupan los motivos del motor', () => {
  assert.equal(reasonCategory('EV insuficiente'), 'EV insuficiente');
  assert.equal(reasonCategory('El modelo se desvía demasiado del mercado'), 'Modelo demasiado lejos del mercado');
  assert.equal(reasonCategory('Cuota fuera del rango de validación (1.50–4.00)'), 'Cuota fuera de rango');
  assert.equal(reasonCategory('Menos de 3 casas en el mercado'), 'Pocas casas en el mercado');
  assert.equal(reasonCategory('Límite de 3 señales por jornada'), 'Límite por jornada o partido');
  assert.equal(reasonCategory(null), 'Sin motivo registrado');
});

test('cada fila guarda motivo, cuota y resultado final, y nunca es una recomendación', () => {
  const r = buildExperimental([row()]).rows[0];
  assert.equal(r.reason, 'EV insuficiente');
  assert.equal(r.odds, 2.1);
  assert.equal(r.status, 'won');
  assert.equal(r.score, '2-0');
  assert.equal(r.profit, 1.1);
  assert.equal(r.recommended, false);
  assert.equal(r.experimental, true);
});

test('pendientes sin beneficio; perdidas -1; medias; nulas 0', () => {
  const out = buildExperimental([
    row({ id: 1, status: 'pending', home_goals: null, away_goals: null }),
    row({ id: 2, status: 'lost', selection: 'draw' }),
    row({ id: 3, status: 'half_won', selection: 'away' }),
    row({ id: 4, status: 'void', selection: 'dc_x2' })
  ]);
  const by = Object.fromEntries(out.rows.map(r => [r.id, r]));
  assert.equal(by[1].profit, null);
  assert.equal(by[2].profit, -1);
  assert.equal(by[3].profit, 0.55);
  assert.equal(by[4].profit, 0);
  assert.equal(out.all.total, 4);
  assert.equal(out.all.pending, 1);
});

test('el resumen separa por motivo y por EV positivo, con intervalos', () => {
  const rows = [];
  for (let i = 0; i < 40; i++) rows.push(row({ id: i, selection: `s${i}`, status: i % 2 ? 'won' : 'lost', ev: i % 4 === 0 ? -0.02 : 0.02 }));
  rows.push(row({ id: 99, reason: 'El modelo se desvía demasiado del mercado', status: 'lost' }));
  const out = buildExperimental(rows);
  assert.equal(out.byReason.length, 2);
  assert.equal(out.byReason[0].category, 'EV insuficiente');
  assert.ok(out.positiveEv.total < out.all.total);
  assert.ok(out.all.yield.lo != null && out.all.yield.hi != null);
  assert.equal(out.disclaimer, EXPERIMENTAL_DISCLAIMER);
  assert.match(out.disclaimer, /No son apuestas recomendadas/);
});
