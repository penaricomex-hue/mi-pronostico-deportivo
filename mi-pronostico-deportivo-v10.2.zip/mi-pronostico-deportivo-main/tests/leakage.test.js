import test from 'node:test';
import assert from 'node:assert/strict';
import { generateRecords, runLeagueBacktest } from '../server/backtest/walkForward.js';
import { fitDixonColes } from '../server/model/dixonColes.js';
import { emptyBins, addObservation, fitCalibration, applyCalibration } from '../server/model/calibration.js';
import { expectedCalibrationError, brierBinary } from '../server/model/metrics.js';
import fs from 'node:fs';

function rng(seed) {
  let s = seed >>> 0;
  return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 2 ** 32; };
}
function poisson(lambda, rand) {
  const L = Math.exp(-lambda);
  let k = 0, p = 1;
  do { k++; p *= rand(); } while (p > L);
  return k - 1;
}

/** Liga sintética: 8 equipos con fuerzas distintas, 3 temporadas, doble vuelta. */
function syntheticLeague(seed = 7) {
  const rand = rng(seed);
  const teams = Array.from({ length: 8 }, (_, i) => ({ name: `T${i}`, att: 0.6 + 0.12 * i, def: 1.3 - 0.1 * i }));
  const seasons = ['2223', '2324', '2425'];
  const matches = [];
  seasons.forEach((season, si) => {
    const start = Date.UTC(2022 + si, 7, 15);
    let day = 0;
    for (let round = 0; round < 2; round++) {
      for (const h of teams) for (const a of teams) {
        if (h === a) continue;
        const date = new Date(start + day * 86400000 * 0.9).toISOString().slice(0, 10);
        day += 1;
        matches.push({ season, date, home: h.name, away: a.name,
          hg: poisson(1.35 * h.att * a.def, rand), ag: poisson(1.1 * a.att * h.def, rand) });
      }
    }
  });
  return matches;
}

const modelKey = r => JSON.stringify([r.date, r.home, r.away, r.model]);

test('el modelo no usa resultados futuros: cambiar partidos posteriores no altera predicciones anteriores', () => {
  const matches = syntheticLeague();
  const base = generateRecords(matches, { evalFrom: '2324', xi: 0.003 });
  assert.ok(base.length > 100);

  // Se manipula TODO lo que ocurre a partir de una fecha de corte
  const cutoff = base[Math.floor(base.length / 2)].date;
  const tampered = matches.map(m => (m.date > cutoff ? { ...m, hg: 9, ag: 0 } : m));
  const after = generateRecords(tampered, { evalFrom: '2324', xi: 0.003 });

  const keyed = new Map(after.map(r => [`${r.date}|${r.home}|${r.away}`, r]));
  let compared = 0;
  for (const r of base) {
    if (r.date > cutoff) continue;
    const other = keyed.get(`${r.date}|${r.home}|${r.away}`);
    assert.ok(other, 'el partido anterior al corte sigue evaluándose');
    assert.equal(modelKey(r), modelKey(other), `predicción distinta en ${r.date} ${r.home}-${r.away}`);
    compared++;
  }
  assert.ok(compared > 50);
});

test('un partido no influye en su propia predicción ni en la del mismo día', () => {
  const base = [];
  for (let i = 0; i < 80; i++) base.push({ date: `2024-01-${String((i % 28) + 1).padStart(2, '0')}`, home: `T${i % 6}`, away: `T${(i + 1) % 6}`, hg: i % 3, ag: (i + 1) % 2 });
  const sameDay = [{ date: '2024-02-10', home: 'T0', away: 'T1', hg: 7, ag: 0 }];
  const a = fitDixonColes(base, { asOf: '2024-02-10' });
  const b = fitDixonColes([...base, ...sameDay], { asOf: '2024-02-10' });
  assert.deepEqual(a.teams.T0, b.teams.T0, 'asOf es excluyente: el mismo día no entra');
});

test('backtest: calibración, pesos y parámetros solo dependen de las temporadas de entrenamiento', () => {
  const matches = syntheticLeague(11);
  const opts = { slug: 'la_liga', trainSeasons: ['2223', '2324'], testSeasons: ['2425'], xiGrid: [0.003], hasOdds: false };
  const a = runLeagueBacktest(matches, opts);

  // Se destruyen los resultados de la temporada de prueba
  const tampered = matches.map(m => (m.season === '2425' ? { ...m, hg: 8, ag: 0 } : m));
  const b = runLeagueBacktest(tampered, opts);

  assert.equal(a.report.xi, b.report.xi, 'la elección de ξ no mira la prueba');
  assert.deepEqual(a.report.calibrationMaps, b.report.calibrationMaps, 'mapas de calibración solo con entrenamiento');
  assert.deepEqual(a.report.train.metrics, b.report.train.metrics, 'métricas de entrenamiento idénticas');
  assert.notDeepEqual(a.report.test.metrics.model, b.report.test.metrics.model, 'la prueba sí cambia (control)');
});

test('el informe versionado separa temporadas: entrenamiento siempre anterior a prueba', () => {
  const report = JSON.parse(fs.readFileSync(new URL('../data/backtest-report.json', import.meta.url), 'utf8'));
  for (const [code, lg] of Object.entries(report.leagues)) {
    assert.ok(['PD', 'CL'].includes(code), `${code}: solo LaLiga y Champions`);
    assert.ok(Math.max(...lg.trainSeasons) < Math.min(...lg.testSeasons), `${code}: entrenamiento posterior a la prueba`);
    assert.ok(!lg.trainSeasons.some(s => lg.testSeasons.includes(s)), `${code}: temporadas repetidas`);
  }
});

test('calibración en datos NO vistos: el mapa ajustado en entrenamiento reduce el error fuera de muestra', () => {
  const rand = rng(99);
  // El modelo está sobreconfiado: dice p pero la frecuencia real es 0.5 + 0.6·(p − 0.5)
  const sample = n => Array.from({ length: n }, () => {
    const p = 0.15 + 0.7 * rand();
    const truth = 0.5 + 0.6 * (p - 0.5);
    return [p, rand() < truth];
  });
  const train = sample(6000), holdout = sample(6000);
  const bins = emptyBins();
  for (const [p, hit] of train) addObservation(bins, p, hit);
  const map = fitCalibration(bins);

  const raw = expectedCalibrationError(holdout);
  const cal = expectedCalibrationError(holdout.map(([p, hit]) => [applyCalibration(map, p), hit]));
  assert.ok(cal.ece < raw.ece / 2, `ECE ${raw.ece.toFixed(4)} -> ${cal.ece.toFixed(4)}`);
  const brier = pairs => pairs.reduce((s, [p, hit]) => s + brierBinary(p, hit), 0) / pairs.length;
  assert.ok(brier(holdout.map(([p, hit]) => [applyCalibration(map, p), hit])) < brier(holdout));
});

test('ECE: predicciones perfectamente calibradas dan ~0', () => {
  const rand = rng(5);
  const pairs = Array.from({ length: 20000 }, () => { const p = rand(); return [p, rand() < p]; });
  assert.ok(expectedCalibrationError(pairs).ece < 0.02);
  assert.equal(expectedCalibrationError([]).ece, null);
});
