import { useState } from 'react';
import { api } from '../api';
import type { Experimental, ExperimentalAgg } from '../types';
import { Badge, Card, Chips, ErrorBox, SectionTitle, Spinner, Stat } from '../components/ui';
import { kickoffDate, odds, signedNum, signedPct } from '../lib/format';

const STATUS: Record<string, string> = { pending: 'Pendiente', won: 'Habría ganado', lost: 'Habría perdido', void: 'Nula', half_won: 'Media ganada', half_lost: 'Media perdida' };

function yieldText(a: ExperimentalAgg) {
  const y = a.yield;
  if (y.mean == null) return '—';
  const ci = y.lo != null && y.hi != null ? ` (${signedNum(y.lo, 1, '%')} a ${signedNum(y.hi, 1, '%')})` : '';
  return `${signedNum(y.mean, 1, '%')}${ci}`;
}

/** Selecciones que el motor rechazó, con su resultado final. NO son recomendaciones. */
export function ExperimentalPanel() {
  const [days, setDays] = useState('90');
  const [data, setData] = useState<Experimental | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = async (d = days) => {
    setLoading(true); setError(null);
    try { setData(await api.experimental(Number(d))); } catch (err) { setError((err as Error).message); } finally { setLoading(false); }
  };

  return (
    <Card>
      <SectionTitle aside={<Badge tone="warn">Experimental · no recomendado</Badge>}>Selecciones rechazadas</SectionTitle>
      <p className="mb-3 text-sm text-muted">
        Qué habría pasado con lo que el sistema descartó (con su motivo, cuota y resultado final). Sirve para comprobar
        si las reglas filtran bien. No son apuestas recomendadas y no cuentan en el rendimiento real.
      </p>
      <div className="flex flex-wrap items-center gap-3">
        <Chips options={[{ value: '30', label: '30 días' }, { value: '90', label: '90 días' }, { value: '365', label: '1 año' }]} value={days} onChange={v => { setDays(v); if (data) void load(v); }} />
        <button type="button" onClick={() => load()} disabled={loading} className="ml-auto rounded-lg border border-line px-3 py-1.5 text-xs hover:border-accent disabled:opacity-60">
          {data ? 'Actualizar' : 'Ver simulación'}
        </button>
      </div>
      <div className="mt-3"><ErrorBox error={error} /></div>
      {loading && <Spinner />}

      {data && !loading && (
        <div className="mt-4 space-y-4">
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            <Stat label="Rechazadas" value={data.all.total} hint={`${data.all.settled} con resultado`} />
            <Stat label="Yield (1 u plana)" value={yieldText(data.all)} hint="intervalo 95%" />
            <Stat label="Rechazadas con EV > 0" value={data.positiveEv.total} hint={`${data.positiveEv.settled} con resultado`} />
            <Stat label="Yield de esas" value={yieldText(data.positiveEv)} hint="intervalo 95%" />
          </div>
          <p className="text-[11px] text-muted">{data.method}</p>

          {data.byReason.length > 0 && (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[480px] text-xs tabular-nums">
                <thead><tr className="border-b border-line text-left text-[11px] uppercase text-muted">
                  <th className="py-2 font-medium">Motivo del rechazo</th><th className="py-2 text-right font-medium">Selecc.</th>
                  <th className="py-2 text-right font-medium">Resueltas</th><th className="py-2 text-right font-medium">Yield</th>
                </tr></thead>
                <tbody>
                  {data.byReason.map(r => (
                    <tr key={r.category} className="border-b border-line/60">
                      <td className="py-1.5">{r.category}</td><td className="py-1.5 text-right">{r.total}</td>
                      <td className="py-1.5 text-right">{r.settled}</td><td className="py-1.5 text-right">{yieldText(r)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          <ul className="space-y-2">
            {data.rows.slice(0, 30).map(r => (
              <li key={r.id} className="rounded-lg border border-line p-3 text-xs">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="truncate text-sm font-semibold">{r.home} {r.score ?? 'vs'} {r.away}</div>
                    <div className="text-muted">{r.competition} · {kickoffDate(r.kickoff)} · {r.label} @ {odds(r.odds)}{r.bookmaker ? ` (${r.bookmaker})` : ''}</div>
                    <div className="mt-0.5 text-muted">Rechazada: <span className="text-text">{r.reason || r.category}</span> · EV {signedPct(r.ev)}</div>
                  </div>
                  <div className="flex flex-col items-end gap-1">
                    <Badge tone={r.status === 'won' || r.status === 'half_won' ? 'good' : r.status === 'lost' || r.status === 'half_lost' ? 'bad' : 'neutral'}>{STATUS[r.status] || r.status}</Badge>
                    {r.profit != null && <span className={r.profit >= 0 ? 'text-good' : 'text-bad'}>{signedNum(r.profit, 2, ' u')}</span>}
                  </div>
                </div>
              </li>
            ))}
          </ul>
          <p className="text-[11px] text-muted">{data.disclaimer}</p>
        </div>
      )}
    </Card>
  );
}
