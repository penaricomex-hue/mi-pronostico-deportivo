import { useState } from 'react';
import { api } from '../api';
import type { Fixture, SameGameCombo, SameGameResponse } from '../types';
import { Badge, Card, Chips, COMPETITIONS, Empty, ErrorBox, SectionTitle, Spinner } from '../components/ui';
import { kickoffDate, odds, pct, signedPct } from '../lib/format';

const LABEL: Record<string, string> = {
  home: 'Gana local', draw: 'Empate', away: 'Gana visitante',
  dc_1x: 'Local o empate', dc_x2: 'Empate o visitante', dc_12: 'Local o visitante',
  over25: 'Más de 2.5', under25: 'Menos de 2.5', btts_yes: 'Ambos marcan: sí', btts_no: 'Ambos marcan: no'
};
const GROUPS: Array<{ title: string; items: string[] }> = [
  { title: '1X2', items: ['home', 'draw', 'away'] },
  { title: 'Doble oportunidad', items: ['dc_1x', 'dc_x2', 'dc_12'] },
  { title: 'Goles', items: ['over25', 'under25'] },
  { title: 'Ambos marcan', items: ['btts_yes', 'btts_no'] }
];
const today = () => new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);

function ComboLine({ c, minEv }: { c: SameGameCombo; minEv: number }) {
  if (!c.ok) return <div className="text-xs text-warn">{c.reason}</div>;
  const corr = c.correlation ?? 1;
  return (
    <div className="space-y-1 text-xs">
      <div className="flex flex-wrap items-center gap-2">
        <span className="font-semibold text-text">{c.selections.map(s => LABEL[s] || s).join(' + ')}</span>
        {corr > 1.03 && <Badge tone="good" title="Las selecciones se favorecen entre sí">Correlación +</Badge>}
        {corr < 0.97 && <Badge tone="warn" title="Las selecciones se penalizan entre sí">Correlación −</Badge>}
      </div>
      <div className="tabular-nums text-muted">
        Prob. conjunta <span className="text-text">{pct(c.joint)}</span> (si fueran independientes: {pct(c.independent)}) ·
        cuota justa <span className="text-text">{odds(c.fairOdds)}</span> ·
        cuota mínima para EV ≥ {(minEv * 100).toFixed(0)}%: <span className="text-text">{odds(c.minimumOdds)}</span>
      </div>
      {c.value && (
        <div className={`tabular-nums ${c.value.ev >= minEv ? 'text-good' : c.value.ev >= 0 ? 'text-warn' : 'text-bad'}`}>
          Con la cuota {odds(c.value.offeredOdds)} que indicas: EV {signedPct(c.value.ev)}
        </div>
      )}
    </div>
  );
}

/** Combinadas del MISMO partido con probabilidad conjunta (no independiente). */
export function SameGamePanel() {
  const [competition, setCompetition] = useState('');
  const [date, setDate] = useState(today());
  const [fixtures, setFixtures] = useState<Fixture[] | null>(null);
  const [chosen, setChosen] = useState<Fixture | null>(null);
  const [selected, setSelected] = useState<string[]>([]);
  const [offered, setOffered] = useState('');
  const [data, setData] = useState<SameGameResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const run = async <T,>(fn: () => Promise<T>) => {
    setLoading(true); setError(null);
    try { return await fn(); } catch (err) { setError((err as Error).message); return null; } finally { setLoading(false); }
  };

  const loadFixtures = async () => {
    setChosen(null); setData(null); setSelected([]);
    const r = await run(() => api.fixtures(date, competition));
    if (r) setFixtures(r.fixtures.filter(f => !['FINISHED', 'IN_PLAY', 'PAUSED'].includes(f.status)));
  };

  const calc = async (f: Fixture, sels: string[], price: string) => {
    const o = Number(price.replace(',', '.'));
    const r = await run(() => api.sameGame(f.id, date, f.competitionCode, sels, Number.isFinite(o) && o > 1 ? o : undefined));
    if (r) setData(r);
  };

  const pick = (f: Fixture) => { setChosen(f); setSelected([]); setData(null); void calc(f, [], ''); };
  const toggle = (s: string) => {
    if (!chosen) return;
    const next = selected.includes(s) ? selected.filter(x => x !== s) : [...selected, s];
    setSelected(next);
    void calc(chosen, next.length >= 2 ? next : [], offered);
  };

  return (
    <Card>
      <SectionTitle>Mismo partido</SectionTitle>
      <p className="mb-3 text-sm text-muted">
        Combina mercados compatibles de un mismo partido. La probabilidad conjunta sale de la distribución de marcadores
        (no se multiplican probabilidades), así que cuenta las dependencias entre mercados. La cuota de la combinada la
        fija tu casa: escríbela para ver el EV.
      </p>
      <div className="space-y-3">
        <Chips options={COMPETITIONS.map(c => ({ value: c.code, label: c.name }))} value={competition} onChange={setCompetition} />
        <div className="flex flex-wrap items-center gap-3">
          <input type="date" value={date} onChange={e => setDate(e.target.value)} className="rounded-lg border border-line bg-transparent px-3 py-2 text-sm" aria-label="Fecha" />
          <button type="button" onClick={loadFixtures} disabled={loading} className="rounded-lg bg-accent px-4 py-2 text-sm font-semibold text-ink disabled:opacity-60">
            Ver partidos
          </button>
        </div>
      </div>

      <div className="mt-3"><ErrorBox error={error} /></div>
      {loading && <Spinner label="Calculando…" />}

      {fixtures && fixtures.length === 0 && <div className="mt-3"><Empty>No hay partidos próximos en esa fecha.</Empty></div>}
      {fixtures && fixtures.length > 0 && (
        <ul className="mt-3 space-y-1.5">
          {fixtures.map(f => (
            <li key={f.id}>
              <button type="button" onClick={() => pick(f)}
                className={`flex w-full items-center justify-between gap-2 rounded-lg border px-3 py-2 text-left text-sm ${chosen?.id === f.id ? 'border-accent' : 'border-line'}`}>
                <span className="min-w-0 truncate">{f.home} vs {f.away}</span>
                <span className="shrink-0 text-xs text-muted">{kickoffDate(f.kickoff)}</span>
              </button>
            </li>
          ))}
        </ul>
      )}

      {chosen && (
        <div className="mt-4 space-y-3">
          {GROUPS.map(g => (
            <div key={g.title}>
              <div className="mb-1 text-[11px] uppercase text-muted">{g.title}</div>
              <div className="flex flex-wrap gap-2">
                {g.items.map(s => (
                  <button key={s} type="button" aria-pressed={selected.includes(s)} onClick={() => toggle(s)}
                    className={`rounded-full border px-3 py-1.5 text-xs ${selected.includes(s) ? 'border-transparent bg-accent text-ink' : 'border-line text-muted'}`}>
                    {LABEL[s]}
                  </button>
                ))}
              </div>
            </div>
          ))}
          <label className="flex items-center gap-2 text-xs text-muted">
            Cuota de tu casa para la combinada
            <input inputMode="decimal" value={offered} placeholder="p. ej. 3.40"
              onChange={e => setOffered(e.target.value)}
              onBlur={() => chosen && selected.length >= 2 && calc(chosen, selected, offered)}
              className="w-24 rounded-lg border border-line bg-transparent px-2 py-1.5 text-sm text-text" />
          </label>
        </div>
      )}

      {data?.combo && <div className="mt-4 rounded-lg border border-line p-3"><ComboLine c={data.combo} minEv={data.minEv} /></div>}

      {data?.combos && !selected.length && (
        <div className="mt-4 space-y-2">
          <div className="text-[11px] uppercase text-muted">Combinaciones compatibles más probables</div>
          {data.combos.slice(0, 8).map(c => (
            <div key={c.selections.join('|')} className="rounded-lg border border-line p-3"><ComboLine c={c} minEv={data.minEv} /></div>
          ))}
        </div>
      )}
      {data && <p className="mt-3 text-[11px] text-muted">{data.oddsNote}</p>}
    </Card>
  );
}
