import type { Analysis, BacktestLeague, Bet, BetStatus, BetSummary, Experimental, Fixture, Parlay, Performance, Pick, SameGameResponse, Signal, Status, ThresholdStudy, ValueRules } from './types';

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

const tz = () => new Date().getTimezoneOffset();

const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

/**
 * Los mensajes de error distinguen sesión caducada, bloqueo temporal y servidor
 * dormido (plan gratuito de Render tarda hasta ~1 min en despertar). Las
 * lecturas (GET) se reintentan si el servidor está arrancando.
 */
async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const isGet = !init?.method || init.method.toUpperCase() === 'GET';
  const attempts = isGet ? 3 : 1;
  let lastError: ApiError | null = null;

  for (let i = 0; i < attempts; i++) {
    let res: Response;
    try {
      res = await fetch(path, {
        ...init,
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', ...(init?.headers || {}) }
      });
    } catch {
      lastError = new ApiError('Sin conexión con el servidor. Comprueba tu red e inténtalo de nuevo.', 0);
      if (i < attempts - 1) { await sleep(3000); continue; }
      throw lastError;
    }

    if ([502, 503, 504].includes(res.status) && i < attempts - 1) {
      lastError = new ApiError('El servidor está arrancando. Reintentando…', res.status);
      await sleep(4000);
      continue;
    }

    let data: any = null;
    try {
      data = await res.json();
    } catch {
      if (res.status === 401) throw new ApiError('Sesión no válida: cierra y vuelve a abrir la app para iniciar sesión.', 401);
      if (res.status === 429) throw new ApiError('Demasiados intentos. Espera unos minutos.', 429);
      if ([502, 503, 504].includes(res.status)) throw new ApiError('El servidor no responde (puede estar despertando). Inténtalo en un minuto.', res.status);
      throw new ApiError(`Respuesta no válida del servidor (HTTP ${res.status})`, res.status);
    }
    if (!res.ok || data?.ok === false) throw new ApiError(data?.error || `HTTP ${res.status}`, res.status);
    return data as T;
  }
  throw lastError || new ApiError('Error desconocido', 0);
}

function qs(params: Record<string, string | number | boolean | null | undefined>) {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) if (v !== null && v !== undefined && v !== '') p.set(k, String(v));
  p.set('tz', String(tz()));
  return p.toString();
}

export const api = {
  status: () => request<Status>('/api/status'),

  fixtures: (date: string, competition: string) =>
    request<{ fixtures: Fixture[]; warnings: string[] }>(`/api/fixtures?${qs({ date, competition })}`),

  analyze: (f: Pick | Fixture, date: string) => {
    const id = 'fixtureId' in f ? f.fixtureId : f.id;
    return request<{ analysis: Analysis }>(`/api/analyze?${qs({ id, date, competition: f.competitionCode })}`);
  },

  valueBets: (competition: string, days: number, includeNearMisses: boolean) =>
    request<{
      analyzed: number; withOdds: number; picks: Pick[]; nearMisses: Pick[]; recorded: number; rules: ValueRules;
      execution: { bookmaker: string | null; mode: 'fixed' | 'best' | null }; warnings: string[];
    }>(`/api/value-bets?${qs({ competition, days, includeNearMisses })}`),

  parlays: (competition: string, legs: number) =>
    request<{ parlays: Parlay[]; candidates: number; assumption: string; warnings: string[] }>(
      `/api/parlay?${qs({ competition, legs })}`
    ),

  sameGame: (id: string, date: string, competition: string, selections: string[] = [], odds?: number) =>
    request<SameGameResponse>(`/api/same-game?${qs({ id, date, competition, selections: selections.join(','), odds })}`),

  experimental: (days: number) => request<Experimental>(`/api/experimental?days=${days}`),

  performance: (days: number) => request<Performance>(`/api/performance?days=${days}`),
  thresholds: (days: number) => request<ThresholdStudy>(`/api/evaluations/thresholds?days=${days}`),
  signals: (days = 90) => request<{ signals: Signal[] }>(`/api/signals?days=${days}`),

  backtest: (competition: string) => request<BacktestLeague>(`/api/backtest?competition=${encodeURIComponent(competition)}`),

  ratings: (competition: string) =>
    request<{ asOf: string; homeAdvantage: number; rho: number; matches: number; teams: Array<{ name: string; attack: number; defense: number; matches: number; effectiveMatches: number }> }>(
      `/api/ratings?competition=${encodeURIComponent(competition)}`
    ),

  bets: {
    list: (period = '') => request<{ bets: Bet[] }>(`/api/bets?period=${period}`),
    summary: (period = 'month') => request<BetSummary>(`/api/bets/summary?period=${period}`),
    create: (body: Record<string, unknown>) => request<{ bet: Bet }>('/api/bets', { method: 'POST', body: JSON.stringify(body) }),
    settle: (id: Bet['id'], result: BetStatus) =>
      request<{ bet: Bet }>(`/api/bets/${id}/settle`, { method: 'POST', body: JSON.stringify({ result }) }),
    remove: (id: Bet['id']) => request<{ ok: boolean }>(`/api/bets/${id}`, { method: 'DELETE' }),
    autoSettle: () => request<{ settled: number; checked: number }>('/api/bets/auto-settle', { method: 'POST' })
  }
};
